#Don't be a thief by stealing other's Hardwork, it took time and effort to make this repo.
#Respect my work by not making any changes here.

START_TEXT = "Send me any file to begin."

FORCE_SUB_TEXT = "In order to use this bot, you've to join my parent channel."

CHANNEL_LINK = "https://t.me/DroneBots"

SUPPORT_LINK = "https://t.me/TeamDrone"

info_text = "This bot is developed by @MaheshChauhan\n\nWritten in python library TELETHON.\n\nBot by : @DroneBots\nSupport : @TeamDrone\n\nV1.4"   

help_text = """**v1.4**

•`Encode` - encode your video into different lib format or resolution

•`HEVC compress` - negligible loss compression

•`FAST compress` - Very fast and Efficient compression

•`Convert` - change formats or extract audio of any video

•`Rename` - rename any file, extension not required

•`SSHOTS` - generate 10 screenshots of your video

•`Trim` - cut your videos"""

source_text = "**Deploy your own bot**"

DEV = "https://t.me/MaheshChauhan"

spam_notice = "This bot is hosted on heroku, and hence can just run one process at a time.Spamming the bot or encoding adult videos will lead you to a ban."

JPG = "LOCAL/video_convertor.jpg"

JPG0 = 'https://telegra.ph/file/d98c559b56ef884ef3bad.jpg'

JPG2 = "LOCAL/20211215_165751.jpg"

JPG3 = "LOCAL/PicsArt_12-16-08.57.15.jpg"

JPG4 = "LOCAL/20211219_000258.jpg"

